===  Geolocalização - Mostre a Localização do seu cliente em seu site ===
Contributors: marcleiton
Donate link: https://marcleitonalmeida.com/geolocalizacao
Tags: geolocalização, woocommerce, localização
Requires at least: 5.2
Tested up to: 5.2
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Utilize esse plugin para adicionar a localização do seu cliente/usuario em seu site de maneira facil e rapida.

== Description ==
Utilize esse plugin para adicionar a localização do seu cliente/usuario em seu site de maneira facil e rapida, nessa versão o plugin mostra apenas a Cidade e o bairro do usuario através do shortcode.

== Changelog ==

Initial release Version: 1.0

== Frequently Asked Questions ==

= Qual é a licença do plug-in? =

* Este plugin é lançado sob uma licença GPL.

= How to install the plugin? =

* Baixe o arquivo em wordpress, ou diretamente em sua loja em PLUGINS > ADICIONAR NOVO.
* Em seguida, procure pela Geolocalização, observe a instalação e seu checkout já está funcionando.
